sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"TankDip/model/model",
], function (Controller) {
	"use strict";
	return Controller.extend("TankDip.controller.Main", {
		_oBusyDialog: null,
		
		onInit: function(){
			this._oBusyDialog = new sap.m.BusyDialog();
		},
		
		
		_load_NozzleReadings: function () {
		this._oBusyDialog = new sap.m.BusyDialog();
		/*	var oModel = new sap.ui.model.json.JSONModel();
        	oModel.loadData("model/model2.json");
        		oModel.attachRequestCompleted(function() {
        	alert(oModel.getProperty("/list/1/name"));
        		});
        	this.getView().byId("select0").setModel(oModel,"list");*/
			
			var val = this.byId("list1").getSelectedItems();
		//	debugger;
			var valStr = val[0].getBindingContext().toString().replace("')", "");
			this.id = valStr.replace("/Things('", "");
			
			this._oBusyDialog.open();
			
    		this._bindInitialize(this.id);
    		
    		//----------Dips and Pump readings ajax call-------------------------//
    		var sURL = "/TankMicroService/tankdip/PumpReading/"+ this.id +"/" + 0;
			
			jQuery.ajax({
				type: "GET",
				dataType: "json",
				url: sURL,
				context : this,
				error   : function(jqXHR, textStatus, errorThrown) {
					var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
					jQuery.sap.log.error("Data loading", sMessage, "index.html");
					sap.m.MessageToast.show(sMessage);	
					//sap.ca.ui.utils.busydialog.releaseBusyDialog();
				},
				success : function(oData, textStatus, jqXHR) {
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						jQuery.sap.log.warning("Data loading", sMessage, "index.html");
						sap.m.MessageToast.show(sMessage);
						
						return;
					}/*else{
							sap.m.MessageToast.show(oData.errorMessage);
					}*/	
					//alert(oData.TimeSeriesData.value.PumpRead4);
					this.oModel = new sap.ui.model.json.JSONModel(oData);
					var oTableNamedModel = this.byId("table01");
					oTableNamedModel.setModel(this.oModel);
		
					var oList = this.byId("listPumps");
					oList.setModel(this.oModel);
					
					/*var oListb = this.byId("form0_111");
					oListb.setModel(this.oModel);*/
					
					for(var i=1; i<=16; i++){
						var temp_r = "/TimeSeriesData/value/0/PumpRead" + i;
						//var temp_s = "/TimeSeriesData/value/0/PumpSales" + i;
						var fpr = "lpr"+i;
						//var fps = "lps"+i;
						var fir = "ir"+i;
					//	var fis = "is"+i;
						var value_r = this.oModel.getProperty(temp_r);
						//var value_s = this.oModel.getProperty(temp_s);
						
						if(value_r === undefined){
							this.byId(fpr).setVisible(false);
							this.byId(fir).setVisible(false);
						}else{
							this.byId(fpr).setVisible(true);
							this.byId(fir).setVisible(true);
						}
						/*if(value_s == null || value_s == undefined){
							this.byId(fps).setVisible(false);
							this.byId(fis).setVisible(false);
						}else{
							this.byId(fps).setVisible(true);
							this.byId(fis).setVisible(true);
						}*/
						//alert(value);
					}
					
					//alert(oData.TimeSeriesData.value[0].PumpRead1);
					//alert(this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead1"));
					//this._getResults(oData);
					//var fr = "lpr"+1;
					//this.byId(fr).setVisible(false);
					//var temp = "/value/0/PumpRead" + 3;
					//var value = this.oModel.getProperty(temp);
					
				}
			});
			this._oBusyDialog.close();
		},
		
		/*_getResults: function(data){
			//debugger;
			var results = [];
				for (var i = 0; i < data.TimeSeriesData.value.length; i++) {
			//	var oTemp = data.list[i].temp;
				//var date = this._formatDate(data.list[i].dt * 1000);
				results.push({
					value: data.TimeSeriesData.value[i].PumpRead1
				});
			}
		},*/
		
		_bindInitialize: function(tid){
			this._oBusyDialog.open();
			
			var sURL = "/TankMicroService/tankdip/initialize/"+ tid;
			
			jQuery.ajax({
				type: "GET",
				dataType: "json",
				url: sURL,
				context : this,
				error   : function(jqXHR, textStatus, errorThrown) {
					var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
					jQuery.sap.log.error("Data loading", sMessage, "index.html");
					sap.m.MessageToast.show(sMessage);	
					sap.ca.ui.utils.busydialog.releaseBusyDialog();
				},
				success : function(oData, textStatus, jqXHR) {
					var oModel = new sap.ui.model.json.JSONModel(oData);
					var oFormModel = this.byId("form0");
					var oFormInit = this.byId("form0_1");
			        oFormModel.setModel(oModel);//, "items");
			        oFormInit.setModel(oModel);
					if (oData === null || oData === undefined) {
						var sMessage = "WARNING. Received a null or undefined response object.";
						jQuery.sap.log.warning("Data loading", sMessage, "index.html");
						sap.m.MessageToast.show(sMessage);
						return;
					}/*else{
							sap.m.MessageToast.show(oData.errorMessage);
					}*/	
					
					/*var oModel = new sap.ui.model.json.JSONModel(oData);
					var oFormModel = this.byId("form0");
					var oFormInit = this.byId("form0_1");
			        oFormModel.setModel(oModel);
			        oFormInit.setModel(oModel);*/

					
			        //alert(oModel.getProperty("/MasterDataValues/value/0/TankPumpNozzle1"));
					//oModel.attachRequestCompleted(function() {
						for(var i=9; i<=16; i++){
							var temp_n = "/TimeSeriesData/value/0/PumpRead" + i;
							var elem = "iir"+i;
						//	var tpz = "tpz"+i;
							var value_n = oModel.getProperty(temp_n);
							//alert(elem);
							//var value_s = this.oModel.getProperty(temp_s);
							
							if(value_n === undefined){
								this.byId(elem).setVisible(false);
								//this.byId(tpz).setVisible(false);
							}else{
								this.byId(elem).setVisible(true);
							//	this.byId(tpz).setVisible(true);
							}
							
						}
					//});
			       //alert(this.oModel.getProperty("/MasterData/value/0/_time"));
				}
			});
			
			this._oBusyDialog.close();
		//	var oRouter = this.getOwnerComponent().getRouter();
		//	oRouter.navTo("Details",{Context:tid});
		},
			/*_SelectecTab: function(oEvent){
				var key =oEvent.getParameters().key;
				if(this.id == "" || this.id == null || this.id == undefined){
					alert("please select tank from the list first");
				}
				if(key == "dip"){this._GetDipReading();}
				if(key == "pump"){this._GetPumpReadings();}
			},*/
			/*_GetDipReading: function(){
				var oTableNamedModel = this.byId("table01");
				oTableNamedModel.setModel(this.oModel);
			},
			_GetPumpReadings: function(){
				var oList = this.byId("listPumps");
				 oList.setModel(this.oModel);
			},*/
			
			/*_upadateInit: function(){
				this._oBusyDialog.open();

				var date = new Date(this.byId("picker0").getValue()).getTimezoneOffset() * 60000;
				var dt = new Date(Date.now() - date).toISOString().slice(0,-1);
				var dt = (date.getFullYear() + "-" + (date.getMonth()+1) + "-" + date.getDate() + " " + date.getHours() + ":" + date.getMinutes() + ":" + date.getSeconds());
				var dt = new Date(this.byId("picker0").getValue());
				alert(date.toISOString().slice(0,-1));
				var initDate = dt+"Z";
				alert(initDate);

				var sURL = "/TankMicroService/tankdip/initialize/" + this.id;
			
				var NozzleData = {
					"_time": initDate,
				     "TankSerialNo": this.byId("Snumber").getValue(),
				     "TankPumpNozzle1": this.byId("tpz1").getValue(),
				     "TankPumpNozzle2": this.byId("tpz2").getValue(),
				     "TankPumpNozzle3": this.byId("tpz3").getValue(),
				     "TankPumpNozzle4": this.byId("tpz4").getValue(),
				     "TankPumpNozzle5": this.byId("tpz5").getValue(),
				     "TankPumpNozzle6": this.byId("tpz6").getValue(),
				     "TankPumpNozzle7": this.byId("tpz7").getValue(),
				     "TankPumpNozzle8": this.byId("tpz8").getValue(),
				     "TankType": this.byId("type").getValue(),
				     "TankSAPID": this.byId("tsid").getValue(),
				     "TankLastServiceDate": this.byId("picker0").getValue()
				};
				
				var send = {"MasterData": {"value":[NozzleData]}};
				send = JSON.stringify(send);
				//console.log(send);
				jQuery.ajax({
					type: "PUT",
					url: sURL,
					data: send,
					contentType: "application/json",
					error   : function(jqXHR, textStatus, errorThrown) {
						var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
						jQuery.sap.log.error("Data loading", sMessage, "index.html");
						sap.m.MessageToast.show(sMessage);		
						sap.ca.ui.utils.busydialog.releaseBusyDialog();
					},
					success : function(oData, textStatus, jqXHR) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							jQuery.sap.log.warning("Data loading", sMessage, "index.html");
							sap.m.MessageToast.show(sMessage);
							sap.m.MessageToast.show(oData.errorMessage);
							return;
						}else{
								sap.m.MessageToast.show(oData.errorMessage);
						}
					}
				});
				
				this._oBusyDialog.close();
			},*/
			
			_putInit: function(){
				this._oBusyDialog.open();
			
				var date = new Date();
				 
				var timestamp = new Date(date + "UTC").toISOString();
				var lastDate = date.toISOString().slice(0,10);
				
				var sURL = "/TankMicroService/tankdip/initialize/" + this.id;
				
				var MasterData = {
					"_time": this.oModel.getProperty("/MasterData/value/0/_time")=="" || this.oModel.getProperty("/MasterData/value/0/_time")==undefined ? timestamp : this.oModel.getProperty("/MasterData/value/0/_time"),
				     "TankSerialNo": this.byId("Snumber").getValue()=="" || this.byId("Snumber").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankSerialNo")=="" ? "" : this.byId("Snumber").getValue(): this.byId("Snumber").getValue(),
				     "TankPumpNozzle1": this.byId("tpz1").getValue()=="" || this.byId("tpz1").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle1")=="" ? "" : this.byId("tpz1").getValue(): this.byId("tpz1").getValue(),
				     "TankPumpNozzle2": this.byId("tpz2").getValue()=="" || this.byId("tpz2").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle2")=="" ? "" : this.byId("tpz2").getValue(): this.byId("tpz2").getValue(),
				     "TankPumpNozzle3": this.byId("tpz3").getValue()=="" || this.byId("tpz3").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle3")=="" ? "" : this.byId("tpz3").getValue(): this.byId("tpz3").getValue(),
				     "TankPumpNozzle4": this.byId("tpz4").getValue()=="" || this.byId("tpz4").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle4")=="" ? "" : this.byId("tpz4").getValue(): this.byId("tpz4").getValue(),
				     "TankPumpNozzle5": this.byId("tpz5").getValue()=="" || this.byId("tpz5").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle5")=="" ? "" : this.byId("tpz5").getValue(): this.byId("tpz5").getValue(),
				     "TankPumpNozzle6": this.byId("tpz6").getValue()=="" || this.byId("tpz6").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle6")=="" ? "" : this.byId("tpz6").getValue(): this.byId("tpz6").getValue(),
				     "TankPumpNozzle7": this.byId("tpz7").getValue()=="" || this.byId("tpz7").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle7")=="" ? "" : this.byId("tpz7").getValue(): this.byId("tpz7").getValue(),
				     "TankPumpNozzle8": this.byId("tpz8").getValue()=="" || this.byId("tpz8").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankPumpNozzle8")=="" ? "" : this.byId("tpz8").getValue(): this.byId("tpz8").getValue(),
				     "TankType": this.byId("type").getValue()=="" || this.byId("type").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankType")=="" ? "" : this.byId("type").getValue() : this.byId("type").getValue(),
				     "TankSAPID": this.byId("tsid").getValue()=="" || this.byId("tsid").getValue()==undefined ? this.oModel.getProperty("/MasterData/value/0/TankSAPID")=="" ? "" : this.byId("tsid").getValue(): this.byId("tsid").getValue(),
				     "TankLastServiceDate": this.oModel.getProperty("/MasterData/value/0/TankLastServiceDate")=="" || this.oModel.getProperty("/MasterData/value/0/TankLastServiceDate")==undefined ? lastDate : this.oModel.getProperty("/MasterData/value/0/TankLastServiceDate")
				};
				
				var TimeSeriesData16 = {
					"_time": this.oModel.getProperty("/MasterData/value/0/_time")=="" || this.oModel.getProperty("/MasterData/value/0/_time")==undefined ? timestamp : this.oModel.getProperty("/MasterData/value/0/_time"),
					"TerritoryManager": this.byId("terrman").getValue()=="" || this.byId("terrman").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/TerritoryManager"): this.byId("terrman").getValue(),
					"DistrictManager": this.byId("dirman").getValue()=="" || this.byId("dirman").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/DistrictManager"): this.byId("dirman").getValue(),
					"SiteID": this.byId("site_id").getValue()=="" || this.byId("site_id").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/SiteID"): this.byId("site_id").getValue(),
					"Tank_Product": this.byId("tankprd").getValue()=="" || this.byId("tankprd").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Tank_Product"): this.byId("tankprd").getValue(),
					"Tank_Capacity": this.byId("tcap").getValue()=="" || this.byId("tcap").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Tank_Capacity"): this.byId("tcap").getValue(),
					"Country": this.byId("country").getValue()=="" || this.byId("country").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Country"): this.byId("country").getValue(),
					"Fuel_Dip_Recon": this.byId("fdre").getValue()=="" || this.byId("fdre").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Recon") : this.byId("fdre").getValue(),
					/*"Fuel_Sales_YTD": this.byId("fsy").getValue(),
					"Fuel_Sales_MTD": this.byId("fsm").getValue(),
					"Fuel_Daily_sales": this.byId("fds").getValue(),*/
					"Fuel_Dip_Pump": this.byId("fdpu").getValue()=="" || this.byId("fdpu").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Pump"): this.byId("fdpu").getValue(),
					"Fuel_Dip_Actual": this.byId("fdaa").getValue()=="" || this.byId("fdaa").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Actual"): this.byId("fdaa").getValue(),
					"Fuel_Adjustments": this.byId("fa").getValue()=="" || this.byId("fa").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Adjustments"): this.byId("fa").getValue(),
					"Fuel_Del_Planned": this.byId("fdpl").getValue()=="" || this.byId("fdpl").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Del_Planned"): this.byId("fdpl").getValue(),
					"Fuel_Del_Actual": this.byId("fda").getValue()=="" || this.byId("fda").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Del_Actual"): this.byId("fda").getValue(),
					"Fuel_Dev_M_Percent": this.byId("fdmp").getValue()=="" || this.byId("fdmp").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dev_M_Percent"): this.byId("fdmp").getValue(),
					"Fuel_Dip_Prelim": this.byId("fdp").getValue()=="" || this.byId("fdp").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Prelim"): this.byId("fdp").getValue(),
					"Fuel_Dip_RFNO": this.byId("fdr").getValue()=="" || this.byId("fdr").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_RFNO"): this.byId("fdr").getValue(),
					"Fuel_recon_dev": this.byId("frd").getValue()=="" || this.byId("frd").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_recon_dev"): this.byId("frd").getValue(),
					"Fuel_Dev_D_Percent": this.byId("fddp").getValue()=="" || this.byId("fddp").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dev_D_Percent"): this.byId("fddp").getValue(),
					"Tank_Product_Description": this.byId("tprodd").getValue()=="" || this.byId("tprodd").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Tank_Product_Description"): this.byId("tprodd").getValue(),
					"PumpRead1": this.byId("irp1").getValue()=="" || this.byId("irp1").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead1"): this.byId("irp1").getValue(),
					"PumpRead2": this.byId("irp2").getValue()=="" || this.byId("irp2").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead2"): this.byId("irp2").getValue(),
					"PumpRead3": this.byId("irp3").getValue()=="" || this.byId("irp3").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead3"): this.byId("irp3").getValue(),
					"PumpRead4": this.byId("irp4").getValue()=="" || this.byId("irp4").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead4"): this.byId("irp4").getValue(),
					"PumpRead5": this.byId("irp5").getValue()=="" || this.byId("irp5").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead5"): this.byId("irp5").getValue(),
					"PumpRead6": this.byId("irp6").getValue()=="" || this.byId("irp6").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead6"): this.byId("irp6").getValue(),
					"PumpRead7": this.byId("irp7").getValue()=="" || this.byId("irp7").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead7"): this.byId("irp7").getValue(),
					"PumpRead8": this.byId("irp8").getValue()=="" || this.byId("irp8").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead8"): this.byId("irp8").getValue(),
					"PumpRead9": this.byId("irp9").getValue()=="" || this.byId("irp9").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead9"): this.byId("irp9").getValue(),
					"PumpRead10": this.byId("irp10").getValue()=="" || this.byId("irp10").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead10"): this.byId("irp10").getValue(),
					"PumpRead11": this.byId("irp11").getValue()=="" || this.byId("irp11").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead11"): this.byId("irp11").getValue(),
					"PumpRead12": this.byId("irp12").getValue()=="" || this.byId("irp12").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead12"): this.byId("irp12").getValue(),
					"PumpRead13": this.byId("irp13").getValue()=="" || this.byId("irp13").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead13"): this.byId("irp13").getValue(),
					"PumpRead14": this.byId("irp14").getValue()=="" || this.byId("irp14").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead14"): this.byId("irp14").getValue(),
					"PumpRead15": this.byId("irp15").getValue()=="" || this.byId("irp15").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead15"): this.byId("irp15").getValue(),
					"PumpRead16": this.byId("irp16").getValue()=="" || this.byId("irp16").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead16"): this.byId("irp16").getValue(),
					"PumpSales1": null,
					"PumpSales2": null,
					"PumpSales3": null,
					"PumpSales4": null,
					"PumpSales5": null,
					"PumpSales6": null,
					"PumpSales7": null,
					"PumpSales8": null
				};
				
				var TimeSeriesData8 = {
					"_time": this.oModel.getProperty("/MasterData/value/0/_time")=="" || this.oModel.getProperty("/MasterData/value/0/_time")==undefined ? timestamp : this.oModel.getProperty("/MasterData/value/0/_time"),
					"TerritoryManager": this.byId("terrman").getValue()=="" || this.byId("terrman").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/TerritoryManager") : this.byId("terrman").getValue(),
					"DistrictManager": this.byId("dirman").getValue()=="" || this.byId("dirman").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/DistrictManager") : this.byId("dirman").getValue(),
					"SiteID": this.byId("site_id").getValue()=="" || this.byId("site_id").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/SiteID") : this.byId("site_id").getValue(),
					"Tank_Capacity": this.byId("tcap").getValue()=="" || this.byId("tcap").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Tank_Capacity") : this.byId("tcap").getValue(),
					"Tank_Product": this.byId("tankprd").getValue()=="" || this.byId("tankprd").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Tank_Product") : this.byId("tankprd").getValue(),
					"Country": this.byId("country").getValue()=="" || this.byId("country").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Country") : this.byId("country").getValue(),
					"Fuel_Dip_Recon": this.byId("fdre").getValue()=="" || this.byId("fdre").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Recon") : this.byId("fdre").getValue(),
					/*"Fuel_Sales_YTD": this.byId("fsy").getValue(),
					"Fuel_Sales_MTD": this.byId("fsm").getValue(),
					"Fuel_Daily_sales": this.byId("fds").getValue(),*/
					"Fuel_Dip_Pump": this.byId("fdpu").getValue()=="" || this.byId("fdpu").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Pump") : this.byId("fdpu").getValue(),
					"Fuel_Dip_Actual": this.byId("fdaa").getValue()=="" || this.byId("fdaa").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Actual") : this.byId("fdaa").getValue(),
					"Fuel_Adjustments": this.byId("fa").getValue()=="" || this.byId("fa").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Adjustments") : this.byId("fa").getValue(),
					"Fuel_Del_Planned": this.byId("fdpl").getValue()=="" || this.byId("fdpl").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Del_Planned") : this.byId("fdpl").getValue(),
					"Fuel_Del_Actual": this.byId("fda").getValue()=="" || this.byId("fda").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Del_Actual") : this.byId("fda").getValue(),
					"Fuel_Dev_M_Percent": this.byId("fdmp").getValue()=="" || this.byId("fdmp").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dev_M_Percent") : this.byId("fdmp").getValue(),
					"Fuel_Dip_Prelim": this.byId("fdp").getValue()=="" || this.byId("fdp").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_Prelim") : this.byId("fdp").getValue(),
					"Fuel_Dip_RFNO": this.byId("fdr").getValue()=="" || this.byId("fdr").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dip_RFNO") : this.byId("fdr").getValue(),
					"Fuel_recon_dev": this.byId("frd").getValue()=="" || this.byId("frd").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_recon_dev") : this.byId("frd").getValue(),
					"Fuel_Dev_D_Percent": this.byId("fddp").getValue()=="" || this.byId("fddp").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Fuel_Dev_D_Percent") : this.byId("fddp").getValue(),
					"Tank_Product_Description": this.byId("tprodd").getValue()=="" || this.byId("tprodd").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/Tank_Product_Description") : this.byId("tprodd").getValue(),
					"PumpRead1": this.byId("irp1").getValue()=="" || this.byId("irp1").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead1") : this.byId("irp1").getValue(),
					"PumpRead2": this.byId("irp2").getValue()=="" || this.byId("irp2").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead2") : this.byId("irp2").getValue(),
					"PumpRead3": this.byId("irp3").getValue()=="" || this.byId("irp3").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead3") : this.byId("irp3").getValue(),
					"PumpRead4": this.byId("irp4").getValue()=="" || this.byId("irp4").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead4") : this.byId("irp4").getValue(),
					"PumpRead5": this.byId("irp5").getValue()=="" || this.byId("irp5").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead5") : this.byId("irp5").getValue(),
					"PumpRead6": this.byId("irp6").getValue()=="" || this.byId("irp6").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead6") : this.byId("irp6").getValue(),
					"PumpRead7": this.byId("irp7").getValue()=="" || this.byId("irp7").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead7") : this.byId("irp7").getValue(),
					"PumpRead8": this.byId("irp8").getValue()=="" || this.byId("irp8").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead8") : this.byId("irp8").getValue(),
					"PumpSales1": null,
					"PumpSales2": null,
					"PumpSales3": null,
					"PumpSales4": null,
					"PumpSales5": null,
					"PumpSales6": null,
					"PumpSales7": null,
					"PumpSales8": null
				};
				
			//	alert(this.byId("tpz4").getValue());
				
				var send;
				var send16 = {"MasterData":MasterData,"TimeSeriesData":TimeSeriesData16};
				var send8 = {"MasterData":MasterData,"TimeSeriesData":TimeSeriesData8};

				if(this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead9") != undefined){
				//	alert("in send 16");
					send = send16;
				}
				else{
					//alert("in send 8");
					send = send8;
				}
			    send = JSON.stringify(send);
				
				var eventstring = new String();
				eventstring = send.toString().replace(/""/g, null);
				/*var test = JSON.stringify({"Master":MasterData});
				console.log(test);*/
				console.log(send);
				
			jQuery.ajax({
					type: "PUT",
					url: sURL,
					data: eventstring,
					contentType: "application/json",
					error   : function(jqXHR, textStatus, errorThrown) {
						var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
						jQuery.sap.log.error("Data loading", sMessage, "index.html");
						sap.m.MessageToast.show(sMessage);		
						sap.ca.ui.utils.busydialog.releaseBusyDialog();
					},
					success : function(oData, textStatus, jqXHR) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							jQuery.sap.log.warning("Data loading", sMessage, "index.html");
							sap.m.MessageToast.show(sMessage);
							return;
						}else{
							var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
								sap.m.MessageToast.show(sMessage);
						}
					}
				});
				//this.byId("form0_1").reset();
				
					this.byId("Snumber").setValue("");
				    this.byId("tpz1").setValue("");
				    this.byId("tpz2").setValue("");
				    this.byId("tpz3").setValue("");
				    this.byId("tpz4").setValue("");
				    this.byId("tpz5").setValue("");
				    this.byId("tpz6").setValue("");
				    this.byId("tpz7").setValue("");
				    this.byId("tpz8").setValue("");
				    this.byId("type").setValue("");
				    this.byId("tsid").setValue("");
					this.byId("terrman").setValue("");
					this.byId("dirman").setValue("");
					this.byId("site_id").setValue("");
					this.byId("tankprd").setValue("");
					this.byId("tcap").setValue("");
					this.byId("country").setValue("");
					this.byId("fdre").setValue("");
					/*"Fuel_Sales_YTD": this.byId("fsy").setValue("");
					"Fuel_Sales_MTD": this.byId("fsm").setValue("");
					"Fuel_Daily_sales": this.byId("fds").setValue("");*/
					this.byId("fdpu").setValue("");
					this.byId("fdaa").setValue("");
					this.byId("fa").setValue("");
					this.byId("fdpl").setValue("");
					this.byId("fda").setValue("");
					this.byId("fdmp").setValue("");
					this.byId("fdp").setValue("");
					this.byId("fdr").setValue("");
					this.byId("frd").setValue("");
					this.byId("fddp").setValue("");
					this.byId("tprodd").setValue("");
					this.byId("irp1").setValue("");
					this.byId("irp2").setValue("");
					this.byId("irp3").setValue("");
					this.byId("irp4").setValue("");
					this.byId("irp5").setValue("");
					this.byId("irp6").setValue("");
					this.byId("irp7").setValue("");
					this.byId("irp8").setValue("");
					this.byId("irp9").setValue("");
					this.byId("irp10").setValue("");
					this.byId("irp11").setValue("");
					this.byId("irp12").setValue("");
					this.byId("irp13").setValue("");
					this.byId("irp14").setValue("");
					this.byId("irp15").setValue("");
					this.byId("irp16").setValue("");
					
				this._oBusyDialog.close();
			},
			
			_putDipReading: function(){
				this._oBusyDialog.open();
				var d = this.byId("picker").getValue();
				var time = this.byId("timer").getValue();
				
				var fd = new Date(d+" "+time+" UTC").toISOString();
				//alert(fd);
				var sURL = "/TankMicroService/tankdip/initialize/" + this.id +"/"+this.byId("shift1").getValue();

				var dipData = {
					"_time": fd,
					//"Shift": this.byId("shift1").getValue(),
					"Fuel_Dip_Prelim": this.byId("inPrl").getValue()
				};
				var send = JSON.stringify(dipData);
				//console.log(send);
				
				jQuery.ajax({
					type: "PUT",
					url: sURL,
					data: send,
					contentType: "application/json",
					error   : function(jqXHR, textStatus, errorThrown) {
						var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
						jQuery.sap.log.error("Data loading", sMessage, "index.html");
						sap.m.MessageToast.show(sMessage);		
						sap.ca.ui.utils.busydialog.releaseBusyDialog();
					},
					success : function(oData, textStatus, jqXHR) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							jQuery.sap.log.warning("Data loading", sMessage, "index.html");
							sap.m.MessageToast.show(sMessage);
							sap.m.MessageToast.show(oData.errorMessage);
							return;
						}else{
							var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
								sap.m.MessageToast.show(sMessage);
						}
					}
				});
				
				this._oBusyDialog.close();
			},
			
			_putPumpReadings: function(){
				this._oBusyDialog.open();
				
				var d = this.byId("picker2").getValue();
				var time = this.byId("pickertime").getValue();
				var shift = this.byId("shift2").getValue();
				
				var fd = new Date(d+" "+time+" UTC").toISOString();
			//	alert(fd);
				var sURL = "/TankMicroService/tankdip/PumpReading/" + this.id +"/" +shift;
				//alert(sURL);
				var pumpData16 = {
					"_time": fd,
					"PumpRead1": this.byId("rp1").getValue()=="" || this.byId("rp1").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead1") : this.byId("rp1").getValue(),
					"PumpRead2": this.byId("rp2").getValue()=="" || this.byId("rp2").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead2") : this.byId("rp2").getValue(),
					"PumpRead3": this.byId("rp3").getValue()=="" || this.byId("rp3").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead3") : this.byId("rp3").getValue(),
					"PumpRead4": this.byId("rp4").getValue()=="" || this.byId("rp4").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead4") : this.byId("rp4").getValue(),
					"PumpRead5": this.byId("rp5").getValue()=="" || this.byId("rp5").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead5") : this.byId("rp5").getValue(),
					"PumpRead6": this.byId("rp6").getValue()=="" || this.byId("rp6").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead6") : this.byId("rp6").getValue(),
					"PumpRead7": this.byId("rp7").getValue()=="" || this.byId("rp7").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead7") : this.byId("rp7").getValue(),
					"PumpRead8": this.byId("rp8").getValue()=="" || this.byId("rp8").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead8") : this.byId("rp8").getValue(),
					"PumpRead9": this.byId("rp9").getValue()=="" || this.byId("rp9").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead9") : this.byId("rp9").getValue(),
					"PumpRead10": this.byId("rp10").getValue()=="" || this.byId("rp10").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead10") : this.byId("rp10").getValue(),
					"PumpRead11": this.byId("rp11").getValue()=="" || this.byId("rp11").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead11") : this.byId("rp11").getValue(),
					"PumpRead12": this.byId("rp12").getValue()=="" || this.byId("rp12").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead12") : this.byId("rp12").getValue(),
					"PumpRead13": this.byId("rp13").getValue()=="" || this.byId("rp13").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead13") : this.byId("rp13").getValue(),
					"PumpRead14": this.byId("rp14").getValue()=="" || this.byId("rp14").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead14") : this.byId("rp14").getValue(),
					"PumpRead15": this.byId("rp15").getValue()=="" || this.byId("rp15").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead15") : this.byId("rp15").getValue(),
					"PumpRead16": this.byId("rp16").getValue()=="" || this.byId("rp16").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead16") : this.byId("rp16").getValue(),
					"mode":"UpdatePlatform" 
				};
				
				var pumpData8 = {
					"_time": fd,
					"PumpRead1": this.byId("rp1").getValue()=="" || this.byId("rp1").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead1") : this.byId("rp1").getValue(),
					"PumpRead2": this.byId("rp2").getValue()=="" || this.byId("rp2").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead2") : this.byId("rp2").getValue(),
					"PumpRead3": this.byId("rp3").getValue()=="" || this.byId("rp3").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead3") : this.byId("rp3").getValue(),
					"PumpRead4": this.byId("rp4").getValue()=="" || this.byId("rp4").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead4") : this.byId("rp4").getValue(),
					"PumpRead5": this.byId("rp5").getValue()=="" || this.byId("rp5").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead5") : this.byId("rp5").getValue(),
					"PumpRead6": this.byId("rp6").getValue()=="" || this.byId("rp6").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead6") : this.byId("rp6").getValue(),
					"PumpRead7": this.byId("rp7").getValue()=="" || this.byId("rp7").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead7") : this.byId("rp7").getValue(),
					"PumpRead8": this.byId("rp8").getValue()=="" || this.byId("rp8").getValue()==undefined ? this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead8") : this.byId("rp8").getValue(),
					"mode":"UpdatePlatform" 
				};
				//var send = {pumpData};
				
				var send;

				if(this.oModel.getProperty("/TimeSeriesData/value/0/PumpRead9") != undefined){
					send = JSON.stringify(pumpData16);
				}
				else{
					send = JSON.stringify(pumpData8);
				}
				var eventstring = new String();
				eventstring = send.toString().replace(/""/g, null);
				
				//console.log(eventstring);
				
				jQuery.ajax({
					type: "PUT",
					url: sURL,
					data: eventstring,
					contentType: "application/json",
					error   : function(jqXHR, textStatus, errorThrown) {
						var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
						jQuery.sap.log.error("Data loading", sMessage, "index.html");
						sap.m.MessageToast.show(sMessage);		
						sap.ca.ui.utils.busydialog.releaseBusyDialog();
					},
					success : function(oData, textStatus, jqXHR) {
						if (oData === null || oData === undefined) {
							var sMessage = "WARNING. Received a null or undefined response object.";
							jQuery.sap.log.warning("Data loading", sMessage, "index.html");
							sap.m.MessageToast.show(sMessage);
							sap.m.MessageToast.show(oData.errorMessage);
							return;
						}else{
							var sMessage = jqXHR.status + " " + jqXHR.statusText + " " + jqXHR.responseText;
								sap.m.MessageToast.show(sMessage);
						}
					}
				});
				
					this.byId("rp1").setValue("");
					this.byId("rp2").setValue("");
					this.byId("rp3").setValue("");
					this.byId("rp4").setValue("");
					this.byId("rp5").setValue("");
					this.byId("rp6").setValue("");
					this.byId("rp7").setValue("");
					this.byId("rp8").setValue("");
					this.byId("rp9").setValue("");
					this.byId("rp10").setValue("");
					this.byId("rp11").setValue("");
					this.byId("rp12").setValue("");
					this.byId("rp13").setValue("");
					this.byId("rp14").setValue("");
					this.byId("rp15").setValue("");
					this.byId("rp16").setValue("");
				
				this._oBusyDialog.close();
			}
		});
	});