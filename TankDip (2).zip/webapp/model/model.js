sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("TwoWay");
			return oModel;
		}

	};

},
function(JSONModel, Device){
	return{
		
		createAPIModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("TwoWay");
			oModel.setData({
				list: [{
					name: ""
				},{
					name: "Pump1"
				}, {
					name: "Pump2"
				}, {
					name: "Pump3"
				},{
					name: "Pump4"
				},{
					name: "Pump5"
				},{
					name: "Pump6"
				},{
					name: "Pump7"
				},{
					name: "Pump8"
				},{
					name: "Pump9"
				},{
					name: "Pump10"
				},{
					name: "Pump11"
				},{
					name: "Pump12"
				},{
					name: "Pump13"
				},{
					name: "Pump14"
				},{
					name: "Pump15"
				},{
					name: "Pump16"
				},{
					name: "Pump17"
				},{
					name: "Pump18"
				},{
					name: "Pump19"
				},{
					name: "Pump20"
				},{
					name: "Pump21"
				},{
					name: "Pump22"
				},{
					name: "Pump23"
				},{
					name: "Pump24"
				},{
					name: "Pump25"
				},{
					name: "Pump26"
				},{
					name: "Pump27"
				},{
					name: "Pump28"
				},{
					name: "Pump29"
				},{
					name: "Pump30"
				},{
					name: "Pump31"
				},{
					name: "Pump32"
				},{
					name: "Pump33"
				},{
					name: "Pump34"
				},{
					name: "Pump35"
				},{
					name: "Pump36"
				},{
					name: "Pump37"
				},{
					name: "Pump38"
				},{
					name: "Pump39"
				},{
					name: "Pump40"
				}]
			});
			return oModel;			
		}
	};
});